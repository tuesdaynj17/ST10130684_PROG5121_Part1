/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

/**
 *
 * @author ST10130684
 */
public class MainApp 
{
    //Declaring scanner class and LoginPage class
    Scanner scan = new Scanner(System.in);
    LoginPage log = new LoginPage();
    
    //Method to prompt the user for registraction details
    public void inputRegistraction()
    {
        //Declaring variables
        String username, password, phone, response;
        
        //Prompting the user for information
        System.out.println("************REGISTRACTION SECTION************");
        System.out.println("Enter a username: ");
        username = scan.nextLine();
        System.out.println("Enter a password: ");
        password = scan.nextLine();
        System.out.println("Enter your SA phone number (+27...): ");
        phone = scan.nextLine();
        
        //Call the registerUser method and store the message it returns
        response = log.registerUser(username, password, phone);
        
        //Shows the registraction message
        System.out.println(response);
    }
    
    //Method to prompt the user for login details
    public void inputLogin()
    {
        //Declaring variables
        String loginUsername, loginPassword, loginMessage;
        boolean loggedIn;
        
        //Prompting the user for information to login
        System.out.println("************LOGIN SECTION************");
        System.out.println("Enter a username: ");
        loginUsername = scan.nextLine();
        System.out.println("Enter a password: ");
        loginPassword = scan.nextLine();
        
        //Call loginUser to check if details match the stored ones
        loggedIn = log.loginUser(loginUsername, loginPassword);     
        
        //Print out the correct login message
        loginMessage = log.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
}
