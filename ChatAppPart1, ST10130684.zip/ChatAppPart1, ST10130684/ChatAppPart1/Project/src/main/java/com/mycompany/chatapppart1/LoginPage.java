/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author ST10130684
 */
public class LoginPage 
{
    //Declaring variables
    String username, password, phonenumber;
    
    //This method checks if whether the username is valid or not.
    public boolean checkUserName(String username)
    {
        return username.contains("_" ) && username.length() <=5;
    }
    
    //This method checks if whether or not the password is strong
    public boolean checkPasswordComplexity(String password)
    {
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        //This for loop schemes through each character of the password
        for (int x = 0; x < password.length(); x++) 
        {
            char c = password.charAt(x);
            //Decision statement to validate each rule.
            if (Character.isUpperCase(c)) 
            {
                hasCapital = true;
            }
            else if(Character.isDigit(c))
            {
                hasNumber = true;
            }
            else if(Character.isLetterOrDigit(c))
            {
                hasSpecial = true;
            }
            
        }
        //this line of code returns the password once validate through each rule
        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }
    
    //This method is to validate the SA Cellphone number.
    public boolean checkCellPhoneNumber(String phone)
    {
        return phone.startsWith("+27") && phone.length() <= 12;
    }
    
    public String registerUser(String username, String password, String phoneNum)
    {
        if (!checkUserName(username))
        {
            return "Username is not correctly formatted, please ensure that your"
                   + " username contains an underscore and is no more than five"
                   + " five characters.";
        }
        
        if (!checkPasswordComplexity(password))
        {
            return "Password is not correctly formatted, please ensure that the "
                   + "password contains at least eight characters, a capital "
                   + "letter, a number, and a special character.";
        }
        
        if (!checkCellPhoneNumber(phoneNum))
        {
            return "Cellphone number is not correctly formatted or does not "
                    + "contain international code.";
        }
        
        this.username = username;
        this.password = password;
        this.phonenumber = phoneNum;
        
        return "User registered successfully!";
    }
    
    //this method is to make sure the details entered are identical.
    public boolean loginUser(String username, String password)
    {
        return this.username.equals(username) && this.password.equals(password);
    }
    
    public String returnLoginStatus(boolean success)
    {
        if (success) 
        {
            return "Welcome " + username + " it is great to see you again.";
        }
        else
        {
            return "Username or password id incorrect, please try again.";
        }
    }
    
    
    
}
